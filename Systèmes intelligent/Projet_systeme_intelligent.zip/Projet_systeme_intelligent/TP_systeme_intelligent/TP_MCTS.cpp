#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include <string>
#include <ctime>


// mieux comprendre l'algo
// - comprendre comment implementer l'algo, quelle structure d'arbre est bien adaptée
// - avancer vraiment

struct noeud
{
    char etat;
    std::vector<noeud*> noeuds_fils;
    bool explore;
    int gain_cumule;
    int compteur_scenario;
    int valeur; // pour les feuilles


};

using arbre = noeud*;

std::map<char,int> resultats_etats_finaux;



bool estFeuille(arbre A)
{
    return A->noeuds_fils.size() == 0;
}

bool dejaExplore(noeud * n)
{
    return n->explore;
}

// int getResultat(char etat_final) // résultat d'un état (une feuille dans l'arbre).
// {
//     return resultats_etats_finaux[etat_final];
// }

std::vector<char> coup_licites(char etat)
{
    std::vector<char> coups;
    return coups;
}

float UBC(char etat, char coup)
{
    return 0;
   // return etat->gain + sqrt( coup * (log(k) / etat->compteur_scenario) )
}

bool chargement_Arbre(std::string nomFichier,arbre & A)
{

    std::ifstream flux;
    flux.open(nomFichier);
    if (flux.is_open())
    {
        char c;
        int x;

        while (flux.good())
        {    
            flux >> c;
            if (c != '#')
            {
                    std::cout << "Racine : " << c << " ";
                    A->etat = c;
                    A->explore = false;

                    flux >> c;
                    std::cout << "SAG : " << c << " ";
                    noeud * n = new noeud;
                    n->etat = c;
                    n->explore = false;
                    A->noeuds_fils.push_back(n); 

                    flux >> c;
                    std::cout << "SAD : " << c << std::endl;
                    noeud * n2 = new noeud;
                    n2->etat = c;
                    n2->explore = false;
                    A->noeuds_fils.push_back(n2);

                    
            }
            else
            {
                    flux >> c;
                    noeud * n3 = new noeud;
                    n3->etat = c;
                    A->noeuds_fils.push_back(n3);

                    std::cout << "feuille : " << c << " ";
                    
                    flux >> x;
                    std::cout << "résultat : " << x << std::endl;
            }
        }
      
        return true;
    }

    else
        return false;
}


void parcourir_arbre(arbre A)
{
    //std::cout<<  A->noeuds_fils.size();

    if (A->noeuds_fils.size() !=0)
    {    
        std::cout << A->etat << " ";
            
        for (noeud * n : A->noeuds_fils)
            {
                    std::cout << n->etat << " ";
            }
        }
}



noeud * trouver_noeud_pas_encore_explore(arbre A)
{
        unsigned int i = 0;
        while ( (i < A->noeuds_fils.size()) && (!dejaExplore(A->noeuds_fils[i])))
        {
            ++i;
        }
        if (i != A->noeuds_fils.size()) // noeud pas encore exploré trouvé
            return  A->noeuds_fils[i];
        else
            return nullptr;
}

void MCTS (std::string nomFichier,arbre & A)
{
    if (chargement_Arbre(nomFichier,A))
    {
        
        // {
        //     noeud * n = trouver_noeud_pas_encore_explore(A);
        //     if (n)
        //     {
        //         A->etat = n;
        //         A->compteur_scenario +=1;
        //         n->explore = true;
        //     }

        //     while ( (n != nullptr) && (!estFeuille(n)) )
        //     {
        //         noeud * n2 = trouver_noeud_pas_encore_explore(n);
        //         if (n2)
        //         {
        //             A->compteur_scenario +=1;
        //             n2->explore = true;
        //         }
        //         n = n2;
        //     }
        // }

        std::cout << "chargement terminé" << std::endl;

    }
    else
        std::cout<< "erreur";

}



noeud * descente(noeud * N)
{
    noeud * n = trouver_noeud_pas_encore_explore(N);
    if ( n == nullptr)
     // noeud * n = UBC(A->noeud_1,A->noeud_2)

    return n;

}

int random(int n)
{
    std::srand(std::time({}));
    int lowest=0;
    int range=(n-lowest)+1;

    return lowest + rand() % range;
}


int roll_out(noeud * n)
{
    if (!estFeuille(n))
    {
        int nb_fils = n->noeuds_fils.size();
        int x =  random(nb_fils-1); // nombre aléatoire entre 0 et nb_fils -1 inclus

        roll_out(n->noeuds_fils[x]);
    }

    else 
        return n->valeur;
}


void update(std::vector<noeud *> & chemin, int resultat)
{
    for (noeud * n : chemin)
    {
        n->compteur_scenario+=1;
        n->gain_cumule += resultat;
        n->explore = true;
    }
}

// void growth(noeud * n)
// {
//         n->compteur_scenario += 1;
//         n->explore = true;

// }
    
 
       






int MCTS(noeud * n)
{
    // si 1er noeud déjà parcouru -> descente
    // growth : 
        // choix du prochain noeud (déjà parcouru) parmis les enfants
        // si tous déjà parcouru :    max UBC(noeud 1, noeud 2)
    // roll out : boucle random jusqu'à une feuille
    // update vers le haut de l'arbre, maj, ajout du gain


    // l'idée mettre les noeuds du chemin dans ce vecteur
    // après l'appel du roll out, parcourir le vecteur et maj les noeud (scenario += 1, gain_total += gain)
    std::vector<noeud *> chemin;

    chemin.push_back(n);

    if (n->explore)
    {
        noeud * n = descente(n);
        chemin.push_back(n);
    }
        
    //growth(n);
    int resultat = roll_out(n);
    update(chemin,resultat);
}


int main()
{
   
    // arbre A = new noeud;
    // MCTS("arbre.txt", A);
    // parcourir_arbre(A);
    // std::cout<<  A->noeuds_fils.size();
    // delete A;
    return 0;
}