#include "driver.hh"
#include <iostream>

Driver::Driver() {}
Driver::~Driver() {}

/*
const Contexte& Driver::getContexte() const {
    //TODO Retourne le contexte pour qu'il soit accessible en dehors de la classe Driver
}

double Driver::getVariable(const std::string & name) const {
    //TODO Retourne la valeur de la variable name
}

void Driver::setVariable(const std::string & name, double value) {
    //TODO Affecte une valeur à une variable avec l'utilisation du contexte variables
}
*/
