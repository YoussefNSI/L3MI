# Information à propos du projet

Mon projet fonctionne bien jusqu'à l'exemple 6, je n'ai pas réussi à implémenter le POUR donc l'exemple 7 ne fonctionnera pas malheureusement.

bloc.h et bloc.cc sont les codes pour représenter les différents élements de la page HTML
Document.h et Document.cc gère la création de la page HTML et fait aussi la gestion des transactions entre le parser et la page pour les conditionnels. Exemple : Si il y a une instruction SI (condition) (instruction1) SINON (instruction2), le parser va éxecuter instruction1 et instruction2 et si il s'avère que condition était faux, Document va annuler instruction1 et laisser instruction2. Driver.hh/Driver.cc gère les valeurs booléennes des conditions.
