let estMinuscule = function c -> 
  if c >= 'a' && c <= 'z' then
    true
  else
    false ;;