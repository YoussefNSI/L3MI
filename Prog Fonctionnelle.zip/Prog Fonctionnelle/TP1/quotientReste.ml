let quotient = function a -> function b -> a / b ;;
let reste = function a -> function b -> a mod b ;;