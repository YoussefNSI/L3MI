let tva = 20.0
let ttc = function prix -> prix +. prix *. tva /. 100.0 ;;

ttc 50.0 ;;