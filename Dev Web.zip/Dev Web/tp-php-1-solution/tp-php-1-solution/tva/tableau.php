<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>Articles HT et TTC</title>
<style type="text/css">
table, th, td {
	border-collapse: collapse;
	border-style: solid;
	border-width: 1px;
}

td {
	width: 100px;
}

.ra {
	text-align: right;
}
</style>
</head>
<body>
<?php
require ("creer.php");
require ("afficher.php");
?>
</body>
</html>