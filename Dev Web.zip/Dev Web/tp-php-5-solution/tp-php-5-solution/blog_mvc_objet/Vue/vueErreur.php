<?php $this->titre = "Mon Blog - Erreur !"; ?>

<p><?= $msgErreur ?></p>
