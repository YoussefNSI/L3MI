<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE employees SYSTEM "employees.dtd">
<employees>
    <employee>
        <name>John Doe</name>
        <salary>50000</salary>
        <age>30</age>
    </employee>
    <employee>
        <name>Jane Doe</name>
        <salary>60000</salary>
        <age>35</age>
    </employee>
</employees>

