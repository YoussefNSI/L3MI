<!DOCTYPE html >
<html>
<head>
    <meta charset="UTF-8" />
    <title>2023 CC-PHP Exercice 2</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
<?php
    // A COMPLETER
?>
</body>
</html>

