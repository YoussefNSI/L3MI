<tr>
	<td>Date (AAAA-MM-JJ)</td>
	<td><input type="date" name="datecarte" value="2014-09-10" /></td>
</tr>
